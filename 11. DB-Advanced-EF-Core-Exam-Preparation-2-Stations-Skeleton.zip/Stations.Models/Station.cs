﻿namespace Stations.Models
{
    public class Station
    {
    }
}
