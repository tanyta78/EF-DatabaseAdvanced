﻿namespace P01_BillsPaymentSystem.Data
{
    public static class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-LAHCAG9\SQLEXPRESS;Database=BillsPaymentSystem;Integrated Security=True;";

    }
}
