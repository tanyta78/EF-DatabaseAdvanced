﻿namespace BusTicketSystem.Client.Core.Commands
{
    using Contracts;
   public class change_trip_statusCommand:ICommand
    {
        public string Execute(string cmd, params string[] args)
        {
            throw new System.NotImplementedException();
        }
    }
}
