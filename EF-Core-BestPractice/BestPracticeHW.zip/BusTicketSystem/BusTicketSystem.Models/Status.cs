﻿namespace BusTicketSystem.Models
{
    public enum Status
    {
        Departed,
        Arrived,
        Delayed,
        Cancelled
    }
}