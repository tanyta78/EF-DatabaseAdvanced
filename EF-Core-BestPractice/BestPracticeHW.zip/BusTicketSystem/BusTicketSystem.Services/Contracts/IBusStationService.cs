﻿namespace BusTicketSystem.Services.Contracts
{
   public interface IBusStationService
   {
       string PrintInfo(int busStationId);
   }
}
