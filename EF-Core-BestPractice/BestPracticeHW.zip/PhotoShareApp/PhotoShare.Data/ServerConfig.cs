﻿namespace PhotoShare.Data
{
    public class ServerConfig
    {
        public static string ConnectionString => "Server=DESKTOP-LAHCAG9\\SQLEXPRESS;Database=PhotoShare;Integrated Security=True;";
    }
}
