﻿namespace PhotoShare.Services.Contracts
{
   public interface IDatabaseInitializeService
    {
        void DatabaseInitialize();

    }
}
