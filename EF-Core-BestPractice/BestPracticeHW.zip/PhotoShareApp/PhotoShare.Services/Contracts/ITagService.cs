﻿namespace PhotoShare.Services.Contracts
{
   public interface ITagService
    {
        string AddTag(string tagName);

    }
}
