﻿namespace PhotoShare.Services
{
    using Models;

    public static class Session
    {
        public static User User { get; set; }
    }
}
