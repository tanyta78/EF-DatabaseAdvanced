﻿namespace PhotoShare.Client.Core.Commands
{
    using System;

    public class AddTagToCommand 
    {
        // AddTagTo <albumName> <tag>
        public string Execute()
        {
            throw new NotImplementedException();
        }
    }
}
