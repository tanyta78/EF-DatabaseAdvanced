﻿namespace PhotoShare.Client.Core.Commands
{
    using System;

    public class PrintFriendsListCommand 
    {
        // PrintFriendsList <username>
        public string Execute(string[] data)
        {
            // TODO prints all friends of user with given username.
            throw new NotImplementedException();
        }
    }
}
