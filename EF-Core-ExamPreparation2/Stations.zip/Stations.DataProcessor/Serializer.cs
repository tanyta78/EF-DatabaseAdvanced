﻿using System;
using Stations.Data;

namespace Stations.DataProcessor
{
    using System.Globalization;
    using System.Linq;
    using Models;
    using Newtonsoft.Json;

    public class Serializer
	{
		public static string ExportDelayedTrains(StationsDbContext context, string dateAsString)
		{

		    var date = DateTime.ParseExact(dateAsString, "dd/MM/yyyy", CultureInfo.InvariantCulture);
		    
		    var delayedTrains = context.Trains
		        .Where(t => t.Trips.Any(tr => tr.Status == TripStatus.Delayed && tr.DepartureTime <= date))
		        .Select(t=> new
		        {
		            t.TrainNumber,
		            DelayedTrips = t.Trips.Where(tr=>tr.Status==TripStatus.Delayed && tr.DepartureTime<=date)
		        }).ToArray()
		        .Select(t=>new
		        {
		            t.TrainNumber,
		            DelayedTimes = t.DelayedTrips.Count(),
		            MaxDelayedTime = t.DelayedTrips.Max(tr=>tr.TimeDifference)
		        })
		        .ToArray();
		    
		    var json = JsonConvert.SerializeObject(delayedTrains, Formatting.Indented);

		    return json;
		}

		public static string ExportCardsTicket(StationsDbContext context, string cardType)
		{
			throw new NotImplementedException();
		}
	}
}