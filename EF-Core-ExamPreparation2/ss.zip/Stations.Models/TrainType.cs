﻿namespace Stations.Models
{
    public enum TrainType
    {
        HighSpeed,
        LongDistance,
        Freight
    }
}
