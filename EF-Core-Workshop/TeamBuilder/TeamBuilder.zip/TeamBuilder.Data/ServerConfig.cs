﻿namespace TeamBuilder.Data
{
   
        public class ServerConfig
        {
            public static string ConnectionString => "Server=DESKTOP-LAHCAG9\\SQLEXPRESS;Database=TeamBuilder;Integrated Security=True;";

        }
    
}
