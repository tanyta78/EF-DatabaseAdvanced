﻿namespace TeamBuilder.Models
{
    public enum Gender
    {
        Male,
        Female
    }
}