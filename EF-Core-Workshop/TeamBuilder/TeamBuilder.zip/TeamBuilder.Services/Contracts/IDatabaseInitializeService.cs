﻿namespace TeamBuilder.Services.Contracts
{
    public interface IDatabaseInitializeService
    {
        void DatabaseInitialize();
    }
}
