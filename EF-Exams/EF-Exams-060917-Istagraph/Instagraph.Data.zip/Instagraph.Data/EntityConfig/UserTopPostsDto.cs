﻿namespace Instagraph.Data.EntityConfig
{
   public class UserTopPostsDto
    {
        public string Username { get; set; }

        public int MostComments { get; set; }
    }
}
