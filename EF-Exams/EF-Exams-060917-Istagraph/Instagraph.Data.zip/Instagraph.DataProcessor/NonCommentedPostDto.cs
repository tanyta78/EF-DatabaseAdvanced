﻿namespace Instagraph.DataProcessor
{
    public class NonCommentedPostDto
    {
        public int Id { get; set; }

        public string Picture { get; set; }

        public string User { get; set; }
    }
}