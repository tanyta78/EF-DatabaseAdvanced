﻿namespace Instagraph.DataProcessor
{
    internal class UserFollowerDto
    {
        public string User { get; set; }

        public string Follower { get; set; }
    }
}