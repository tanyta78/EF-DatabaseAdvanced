﻿namespace P01_HospitalDatabase
{
   public class Configuration
        {
            public const string ConnectionString = @"Server=DESKTOP-LAHCAG9\SQLEXPRESS;Database=Hospital;Integrated Security=True;";
        }
    
}
