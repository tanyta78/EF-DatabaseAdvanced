﻿namespace P03_SalesDatabase
{
    public class Configuration
    {
        public const string ConnectionString = @"Server=DESKTOP-LAHCAG9\SQLEXPRESS;Database=SalesDb;Integrated Security=True;";
    }
}

