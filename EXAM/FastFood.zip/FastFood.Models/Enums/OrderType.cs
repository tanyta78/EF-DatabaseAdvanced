﻿namespace FastFood.Models.Enums
{
    public enum OrderType
    {
        ForHere,
        ToGo
    }
}
