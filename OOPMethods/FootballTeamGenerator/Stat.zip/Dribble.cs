﻿namespace FootballTeamGenerator
{
   public class Dribble:Stat
    {
        public Dribble(int value) : base(value)
        {
        }
    }
}
