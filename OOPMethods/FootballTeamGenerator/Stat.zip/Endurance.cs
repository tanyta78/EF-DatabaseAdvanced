﻿namespace FootballTeamGenerator
{
   public class Endurance:Stat
    {
        public Endurance(int value) : base(value)
        {
        }
    }
}
