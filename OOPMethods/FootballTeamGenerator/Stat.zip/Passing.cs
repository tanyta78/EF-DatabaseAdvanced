﻿namespace FootballTeamGenerator
{
   public class Passing:Stat
    {
        public Passing(int value) : base(value)
        {
        }
    }
}
