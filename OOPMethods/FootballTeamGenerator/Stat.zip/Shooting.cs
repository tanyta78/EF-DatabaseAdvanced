﻿namespace FootballTeamGenerator
{
   public class Shooting:Stat
    {
        public Shooting(int value) : base(value)
        {
        }
    }
}
