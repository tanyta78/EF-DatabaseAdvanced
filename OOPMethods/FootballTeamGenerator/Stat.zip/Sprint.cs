﻿namespace FootballTeamGenerator
{
   public class Sprint:Stat
    {
        public Sprint(int value) : base(value)
        {
        }
    }
}
